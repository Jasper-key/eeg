window.globals = {

    "mark_7": ["LOC_A1", "ROC_A1", "CHIN", "C3_A2", "C4_A1", "O1_A2", "O2_A1"],
    "marks": ["Pz-Oz"],
    "mark_color": ["#FFD258", "#FFD258", "#FFFFFF", "#00FF5C", "#00FF5C", "#00E1FF", "#00E1FF"],
    "algorithms": [
        ["算法一", "one_result"],
        ["算法二", "two_result"],
        ["算法三", "three_result"]
    ],
    "known_result": "vi",
    "unit_numnwe": [70, 50, 30, 40, 50, 60, 70]
}